var searchData=
[
  ['humanmove_0',['humanMove',['../othello_8c.html#ae6a16afc64f814ac762fce742a67011c',1,'othello.c']]]
];
