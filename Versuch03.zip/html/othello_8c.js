var othello_8c =
[
    [ "executeMove", "othello_8c.html#a51baf583d32c9aa03a9b848c1543d950", null ],
    [ "humanMove", "othello_8c.html#ae6a16afc64f814ac762fce742a67011c", null ],
    [ "initializeBoard", "othello_8c.html#abfc51f9d5ac437ac402d13f64edbb559", null ],
    [ "isValidMove", "othello_8c.html#ad5994b1e2e4cad59636a37bf6e85777d", null ],
    [ "main", "othello_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "moveCursor", "othello_8c.html#a09e577a32044a0d8a636a1bfd2124aa2", null ],
    [ "onBoard", "othello_8c.html#aa80842d7c991b51cf34ff604bcc74a83", null ],
    [ "play", "othello_8c.html#ad7727ab08e9ee1352857633c04a45bbc", null ],
    [ "possibleMoves", "othello_8c.html#a0bf891fd5e850f437239149e3da998dd", null ],
    [ "showBoard", "othello_8c.html#a1a7070b65c512fc32be5302065a0d389", null ],
    [ "winner", "othello_8c.html#a2f580467851628016e33180c5b7d7d3f", null ],
    [ "getPlayerFn", "othello_8c.html#a4aa543379f11ac88400b62c87d8d7805", null ]
];