var searchData=
[
  ['main_0',['main',['../othello_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'othello.c']]],
  ['movecursor_1',['moveCursor',['../othello_8c.html#a09e577a32044a0d8a636a1bfd2124aa2',1,'othello.c']]]
];
