var searchData=
[
  ['executemove_0',['executeMove',['../othello_8c.html#a51baf583d32c9aa03a9b848c1543d950',1,'executeMove(int board[HEIGHT][WIDTH], const int currentPlayer, const int posX, const int posY):&#160;othello.c'],['../othello_k_i_8c.html#a51baf583d32c9aa03a9b848c1543d950',1,'executeMove(int board[HEIGHT][WIDTH], const int currentPlayer, const int posX, const int posY):&#160;othello.c'],['../test_8c.html#ac940ce6a8ed80898c32b808365c9c967',1,'executeMove(int board[HEIGHT][WIDTH], const int player, const int posX, const int posY):&#160;othello.c']]],
  ['executemovetest_1',['executeMoveTest',['../test_8c.html#aff4fb2285a3fb7176397721d1e2e9c36',1,'test.c']]]
];
