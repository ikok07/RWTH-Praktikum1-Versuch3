var searchData=
[
  ['computermove_0',['computerMove',['../othello_k_i_8c.html#aba3c26c0c48bb2e6f46b0d188f2695b1',1,'computerMove(int board[HEIGHT][WIDTH], const int currentPlayer):&#160;othelloKI.c'],['../othello_k_i_8h.html#aba3c26c0c48bb2e6f46b0d188f2695b1',1,'computerMove(int board[HEIGHT][WIDTH], const int currentPlayer):&#160;othelloKI.c']]]
];
