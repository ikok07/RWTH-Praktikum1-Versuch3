var searchData=
[
  ['winner_0',['winner',['../othello_8c.html#a2f580467851628016e33180c5b7d7d3f',1,'winner(const int board[HEIGHT][WIDTH]):&#160;othello.c'],['../test_8c.html#a2f580467851628016e33180c5b7d7d3f',1,'winner(const int board[HEIGHT][WIDTH]):&#160;othello.c']]],
  ['winnertest_1',['winnerTest',['../test_8c.html#a43259b7eb46aa68fc14cad3b1fbd8c4b',1,'test.c']]]
];
