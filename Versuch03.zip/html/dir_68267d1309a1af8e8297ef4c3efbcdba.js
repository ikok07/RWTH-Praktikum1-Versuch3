var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "othello.c", "othello_8c.html", "othello_8c" ],
    [ "othelloKI.c", "othello_k_i_8c.html", "othello_k_i_8c" ],
    [ "test.c", "test_8c.html", "test_8c" ]
];