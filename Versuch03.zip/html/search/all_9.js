var searchData=
[
  ['showboard_0',['showBoard',['../othello_8c.html#a1a7070b65c512fc32be5302065a0d389',1,'showBoard(const int board[HEIGHT][WIDTH]):&#160;othello.c'],['../test_8c.html#a1a7070b65c512fc32be5302065a0d389',1,'showBoard(const int board[HEIGHT][WIDTH]):&#160;othello.c']]]
];
