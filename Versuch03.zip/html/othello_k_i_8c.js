var othello_k_i_8c =
[
    [ "computerMove", "othello_k_i_8c.html#aba3c26c0c48bb2e6f46b0d188f2695b1", null ],
    [ "executeMove", "othello_k_i_8c.html#a51baf583d32c9aa03a9b848c1543d950", null ],
    [ "isValidMove", "othello_k_i_8c.html#ad5994b1e2e4cad59636a37bf6e85777d", null ],
    [ "possibleMoves", "othello_k_i_8c.html#a0bf891fd5e850f437239149e3da998dd", null ]
];