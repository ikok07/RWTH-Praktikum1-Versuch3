var searchData=
[
  ['othello_2ec_0',['othello.c',['../othello_8c.html',1,'']]],
  ['othelloki_2ec_1',['othelloKI.c',['../othello_k_i_8c.html',1,'']]],
  ['othelloki_2eh_2',['othelloKI.h',['../othello_k_i_8h.html',1,'']]]
];
