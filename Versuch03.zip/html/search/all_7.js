var searchData=
[
  ['play_0',['play',['../othello_8c.html#ad7727ab08e9ee1352857633c04a45bbc',1,'othello.c']]],
  ['possiblemoves_1',['possibleMoves',['../othello_8c.html#a0bf891fd5e850f437239149e3da998dd',1,'possibleMoves(const int board[HEIGHT][WIDTH], const int currentPlayer):&#160;othello.c'],['../othello_k_i_8c.html#a0bf891fd5e850f437239149e3da998dd',1,'possibleMoves(const int board[HEIGHT][WIDTH], const int currentPlayer):&#160;othello.c'],['../test_8c.html#acfdc15c9e4ecac423da96fc8960debdc',1,'possibleMoves(const int board[HEIGHT][WIDTH], const int player):&#160;othello.c']]],
  ['possiblemovestest_2',['possibleMovesTest',['../test_8c.html#a2d4cf9c2060b3963c0896eb771c02197',1,'test.c']]],
  ['printtestinit_3',['printTestInit',['../test_8c.html#afe1b5e9492c299dbcb0df0a25790222d',1,'test.c']]]
];
