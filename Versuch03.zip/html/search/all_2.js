var searchData=
[
  ['getplayerfn_0',['getPlayerFn',['../othello_8c.html#a4aa543379f11ac88400b62c87d8d7805',1,'othello.c']]]
];
