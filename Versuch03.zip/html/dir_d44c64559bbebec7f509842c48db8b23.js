var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "config.h", "config_8h.html", "config_8h" ],
    [ "othelloKI.h", "othello_k_i_8h.html", "othello_k_i_8h" ],
    [ "test.h", "test_8h.html", "test_8h" ]
];