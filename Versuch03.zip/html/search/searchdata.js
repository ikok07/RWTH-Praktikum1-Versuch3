var indexSectionsWithContent =
{
  0: "ceghimoprstvw",
  1: "cot",
  2: "cehimoprsw",
  3: "cghtvw",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

