var othello_k_i_8h =
[
    [ "computerMove", "othello_k_i_8h.html#aba3c26c0c48bb2e6f46b0d188f2695b1", null ]
];