var searchData=
[
  ['onboard_0',['onBoard',['../othello_8c.html#aa80842d7c991b51cf34ff604bcc74a83',1,'onBoard(const int posX, const int posY):&#160;othello.c'],['../test_8c.html#aa80842d7c991b51cf34ff604bcc74a83',1,'onBoard(const int posX, const int posY):&#160;othello.c']]],
  ['onboardtest_1',['onBoardTest',['../test_8c.html#aea72b59dfbddedb5b91d91322a989e04',1,'test.c']]],
  ['othello_2',['Othello',['../index.html',1,'']]],
  ['othello_2ec_3',['othello.c',['../othello_8c.html',1,'']]],
  ['othelloki_2ec_4',['othelloKI.c',['../othello_k_i_8c.html',1,'']]],
  ['othelloki_2eh_5',['othelloKI.h',['../othello_k_i_8h.html',1,'']]]
];
