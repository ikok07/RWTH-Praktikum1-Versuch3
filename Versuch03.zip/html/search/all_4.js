var searchData=
[
  ['initializeboard_0',['initializeBoard',['../othello_8c.html#abfc51f9d5ac437ac402d13f64edbb559',1,'othello.c']]],
  ['isvalidmove_1',['isValidMove',['../othello_8c.html#ad5994b1e2e4cad59636a37bf6e85777d',1,'isValidMove(const int board[HEIGHT][WIDTH], const int currentPlayer, const int posX, const int posY):&#160;othello.c'],['../othello_k_i_8c.html#ad5994b1e2e4cad59636a37bf6e85777d',1,'isValidMove(const int board[HEIGHT][WIDTH], const int currentPlayer, const int posX, const int posY):&#160;othello.c'],['../test_8c.html#a5bc150a3d9dccbd4e1c2d8410f60e633',1,'isValidMove(const int board[HEIGHT][WIDTH], const int player, const int posX, const int posY):&#160;othello.c']]],
  ['isvalidmovetest_2',['isValidMoveTest',['../test_8c.html#a517699d022e2966b0d5705478c763c00',1,'test.c']]]
];
