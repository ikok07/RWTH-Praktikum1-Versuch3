var searchData=
[
  ['computer_0',['COMPUTER',['../config_8h.html#a51d3d2b0998c1ec1f626c905822c26f3',1,'config.h']]],
  ['computermove_1',['computerMove',['../othello_k_i_8c.html#aba3c26c0c48bb2e6f46b0d188f2695b1',1,'computerMove(int board[HEIGHT][WIDTH], const int currentPlayer):&#160;othelloKI.c'],['../othello_k_i_8h.html#aba3c26c0c48bb2e6f46b0d188f2695b1',1,'computerMove(int board[HEIGHT][WIDTH], const int currentPlayer):&#160;othelloKI.c']]],
  ['config_2eh_2',['config.h',['../config_8h.html',1,'']]]
];
