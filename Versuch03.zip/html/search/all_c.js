var searchData=
[
  ['width_0',['WIDTH',['../config_8h.html#a9649ab8139c4c2ea5c93625b30d92a05',1,'config.h']]],
  ['winner_1',['winner',['../othello_8c.html#a2f580467851628016e33180c5b7d7d3f',1,'winner(const int board[HEIGHT][WIDTH]):&#160;othello.c'],['../test_8c.html#a2f580467851628016e33180c5b7d7d3f',1,'winner(const int board[HEIGHT][WIDTH]):&#160;othello.c']]],
  ['winnertest_2',['winnerTest',['../test_8c.html#a43259b7eb46aa68fc14cad3b1fbd8c4b',1,'test.c']]]
];
