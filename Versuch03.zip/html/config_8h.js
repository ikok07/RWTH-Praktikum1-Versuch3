var config_8h =
[
    [ "COMPUTER", "config_8h.html#a51d3d2b0998c1ec1f626c905822c26f3", null ],
    [ "HEIGHT", "config_8h.html#af728b7647e0b8c49832983a31f9a2e9b", null ],
    [ "HUMAN", "config_8h.html#a4191c18db9be6efa8d87fcb0f5b3c98d", null ],
    [ "TEST", "config_8h.html#a5719694a3e41e6610a8dfc42f73bc0b4", null ],
    [ "VERBOSE", "config_8h.html#a4a20323806e186f80a443d377d400e69", null ],
    [ "WIDTH", "config_8h.html#a9649ab8139c4c2ea5c93625b30d92a05", null ]
];