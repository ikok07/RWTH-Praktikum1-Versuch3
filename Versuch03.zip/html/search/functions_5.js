var searchData=
[
  ['onboard_0',['onBoard',['../othello_8c.html#aa80842d7c991b51cf34ff604bcc74a83',1,'onBoard(const int posX, const int posY):&#160;othello.c'],['../test_8c.html#aa80842d7c991b51cf34ff604bcc74a83',1,'onBoard(const int posX, const int posY):&#160;othello.c']]],
  ['onboardtest_1',['onBoardTest',['../test_8c.html#aea72b59dfbddedb5b91d91322a989e04',1,'test.c']]]
];
