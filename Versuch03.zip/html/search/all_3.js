var searchData=
[
  ['height_0',['HEIGHT',['../config_8h.html#af728b7647e0b8c49832983a31f9a2e9b',1,'config.h']]],
  ['human_1',['HUMAN',['../config_8h.html#a4191c18db9be6efa8d87fcb0f5b3c98d',1,'config.h']]],
  ['humanmove_2',['humanMove',['../othello_8c.html#ae6a16afc64f814ac762fce742a67011c',1,'othello.c']]]
];
